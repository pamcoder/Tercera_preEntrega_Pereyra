from setuptools import setup

setup(
    
    name = "pre_Entrega_2",
    version = "1.0",
    description = "Paquete para la pre-entrega 2",
    author = "Pamela Pereyra",
    author_email ="pame240393@hotmail.com",

    packages = ["paquete1"]
)

